/**
 * e-MON SURAT BNNK BITUNG
 * Monitoring Surat Masuk & Disposisi
 * Backend Google Apps Script + Google Sheets + Google Drive
 *
 * Struktur sheet:
 * surat_masuk, histori_tindaklanjut, users, audit_trail
 *
 * Catatan keamanan:
 * - Dashboard dan data detail membutuhkan login.
 * - Password disimpan sebagai SHA-256 hash.
 * - Lampiran tidak dibuat publik secara otomatis.
 */

const APP_NAME = "e-MON SURAT BNNK BITUNG";
const TZ = "Asia/Makassar"; // WITA
const FOLDER_ATTACHMENT_NAME = "FMonSurat_Attachments_BNNK_Bitung";
const MAX_FILE_SIZE = 5 * 1024 * 1024;

const SCHEMA = {
  surat_masuk: [
    "id","nomor_agenda","nomor_surat","tanggal_surat","tanggal_masuk",
    "asal_surat","pengirim","perihal","jenis_surat","sifat_surat",
    "klasifikasi","prioritas","tujuan_disposisi","instruksi_disposisi",
    "tanggal_disposisi","target_penyelesaian","penanggung_jawab",
    "tindak_lanjut","progress","status","keterangan","lampiran",
    "created_by","created_at","updated_at"
  ],
  histori_tindaklanjut: [
    "id","surat_id","tanggal","aktivitas","progress_lama","progress_baru",
    "status","keterangan","user"
  ],
  users: ["id","nama","username","password_hash","role","status"],
  audit_trail: ["id","waktu","user","aksi","detail"]
};

function doGet() {
  checkAndAutoInit();
  return HtmlService.createTemplateFromFile("Index")
    .evaluate()
    .setTitle(APP_NAME)
    .addMetaTag("viewport","width=device-width, initial-scale=1")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("🛡️ e-MON SURAT BNNK")
    .addItem("🛠️ Inisialisasi / Periksa Database","initDatabase")
    .addItem("🔐 Reset User Default","resetDefaultUsers")
    .addToUi();
}

function initDatabase() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  Object.keys(SCHEMA).forEach(name => {
    let sh = ss.getSheetByName(name);
    if (!sh) sh = ss.insertSheet(name);
    const headers = SCHEMA[name];
    if (sh.getLastRow() === 0) {
      sh.getRange(1,1,1,headers.length).setValues([headers]);
    } else {
      const current = sh.getRange(1,1,1,Math.max(sh.getLastColumn(),headers.length)).getValues()[0];
      const same = headers.every((h,i) => current[i] === h);
      if (!same) {
        sh.clear();
        sh.getRange(1,1,1,headers.length).setValues([headers]);
      }
    }
    formatSheet(sh, headers.length);
  });
  resetDefaultUsers(false);
  getAttachmentFolder();
  const msg = "Database " + APP_NAME + " berhasil disiapkan.";
  try { SpreadsheetApp.getUi().alert(msg); } catch(e) { Logger.log(msg); }
  return {success:true,message:msg};
}

function formatSheet(sh, cols) {
  sh.getRange(1,1,1,cols)
    .setBackground("#7A0019")
    .setFontColor("#FFFFFF")
    .setFontWeight("bold")
    .setHorizontalAlignment("center")
    .setWrap(true);
  sh.setFrozenRows(1);
  if (sh.getMaxRows() > 1) sh.getRange(2,1,sh.getMaxRows()-1,cols).setVerticalAlignment("middle");
  try { sh.autoResizeColumns(1, cols); } catch(e) {}
}

function checkAndAutoInit() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss.getSheetByName("surat_masuk") || !ss.getSheetByName("users")) initDatabase();
}

function getSheet(name) {
  checkAndAutoInit();
  return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name);
}

function getAttachmentFolder() {
  const it = DriveApp.getFoldersByName(FOLDER_ATTACHMENT_NAME);
  if (it.hasNext()) return it.next();
  return DriveApp.createFolder(FOLDER_ATTACHMENT_NAME);
}

function hashPassword(password) {
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, String(password));
  return bytes.map(b => {
    const v = b < 0 ? b + 256 : b;
    return ("0" + v.toString(16)).slice(-2);
  }).join("");
}

function parseDateSafely(v) {
  if (!v) return null;
  if (v instanceof Date && !isNaN(v.getTime())) return v;
  const d = new Date(v);
  return isNaN(d.getTime()) ? null : d;
}

function formatDateDisplay(v) {
  const d = parseDateSafely(v);
  return d ? Utilities.formatDate(d,TZ,"dd/MM/yyyy") : "-";
}

function formatDateInput(v) {
  const d = parseDateSafely(v);
  return d ? Utilities.formatDate(d,TZ,"yyyy-MM-dd") : "";
}

function nowWita() { return new Date(); }

function normalizeStatus(progress, target) {
  const p = Number(progress) || 0;
  if (p >= 100) return "SELESAI";
  const d = parseDateSafely(target);
  if (d) {
    const today = new Date();
    today.setHours(0,0,0,0);
    const t = new Date(d.getTime());
    t.setHours(0,0,0,0);
    if (t < today) return "OVERDUE";
  }
  return p > 0 ? "DALAM PROSES" : "BELUM DITINDAKLANJUTI";
}

function getSessionUser(username) {
  const sh = getSheet("users");
  const data = sh.getDataRange().getValues();
  for (let i=1;i<data.length;i++) {
    if (String(data[i][2]).trim() === String(username).trim() && String(data[i][5]) === "Aktif") {
      return {id:data[i][0],name:data[i][1],username:data[i][2],role:data[i][4]};
    }
  }
  return null;
}

function loginUser(username,password) {
  const sh = getSheet("users");
  const data = sh.getDataRange().getValues();
  const supplied = String(password || "");
  for (let i=1;i<data.length;i++) {
    const u = String(data[i][2]).trim();
    const stored = String(data[i][3]).trim();
    if (u === String(username).trim() && String(data[i][5]) === "Aktif") {
      const ok = stored === hashPassword(supplied) || stored === supplied; // kompatibilitas DB lama
      if (ok) {
        logAudit(data[i][1],"LOGIN","Login berhasil");
        return {success:true,user:{id:data[i][0],name:data[i][1],username:u,role:data[i][4]}};
      }
    }
  }
  return {success:false,message:"Username atau password salah / akun tidak aktif."};
}

function resetDefaultUsers(showAlert) {
  const sh = getSheet("users");
  const existing = sh.getDataRange().getValues();
  const defaults = [
    ["USR-001","Administrator BNNK Bitung","admin",hashPassword("admin123"),"ADMIN","Aktif"],
    ["USR-002","Pimpinan BNNK Bitung","pimpinan",hashPassword("bnnk123"),"PIMPINAN","Aktif"],
    ["USR-003","Petugas Persuratan","petugas",hashPassword("petugas123"),"PETUGAS","Aktif"]
  ];
  const names = defaults.map(x=>x[2]);
  for (let i=0;i<defaults.length;i++) {
    let found = -1;
    for (let r=1;r<existing.length;r++) if (String(existing[r][2])===names[i]) {found=r+1;break;}
    if (found > 0) sh.getRange(found,1,1,6).setValues([defaults[i]]);
    else sh.appendRow(defaults[i]);
  }
  if (showAlert !== false) {
    try { SpreadsheetApp.getUi().alert("User default dibuat/reset.\n\nadmin / admin123\npimpinan / bnnk123\npetugas / petugas123"); } catch(e) {}
  }
  return {success:true};
}

function canWrite(role) { return ["ADMIN","PETUGAS"].indexOf(role) >= 0; }
function canManageUsers(role) { return role === "ADMIN"; }

function getDashboardData() {
  const list = getAllSurat();
  let total=0,belum=0,proses=0,selesai=0,overdue=0,totalProgress=0;
  const attention=[], highPriority=[];
  list.forEach(d=>{
    total++; totalProgress += Number(d.progress)||0;
    if(d.status==="BELUM DITINDAKLANJUTI") belum++;
    if(d.status==="DALAM PROSES") proses++;
    if(d.status==="SELESAI") selesai++;
    if(d.status==="OVERDUE") overdue++;
    const target=parseDateSafely(d.target_penyelesaian);
    if(target && d.progress<100){
      const t=new Date(target); t.setHours(0,0,0,0);
      const today=new Date(); today.setHours(0,0,0,0);
      const diff=Math.ceil((t-today)/86400000);
      if(diff<0) attention.push({id:d.id,perihal:d.perihal,progress:d.progress,target:d.target_penyelesaian_display,status:"Overdue "+Math.abs(diff)+" hari",badge:"danger"});
      else if(diff<=3) attention.push({id:d.id,perihal:d.perihal,progress:d.progress,target:d.target_penyelesaian_display,status:"H-"+diff+" menuju target",badge:"warning text-dark"});
    }
    if(d.prioritas==="Tinggi" && d.progress<100) highPriority.push({id:d.id,perihal:d.perihal,progress:d.progress,target:d.target_penyelesaian_display,pic:d.penanggung_jawab});
  });
  return {
    kpi:{total,belum,proses,selesai,overdue,avgProgress:total?Math.round(totalProgress/total):0,completionRate:total?Math.round(selesai/total*100):0},
    attentionList:attention.slice(0,10),
    highPriority:highPriority.slice(0,10)
  };
}

function getAllSurat() {
  const sh=getSheet("surat_masuk"), data=sh.getDataRange().getValues(), out=[];
  for(let i=1;i<data.length;i++){
    const r=data[i]; if(!r[0]) continue;
    const progress=Number(r[18])||0;
    const target=r[15];
    const status=normalizeStatus(progress,target);
    out.push({
      id:String(r[0]), nomor_agenda:String(r[1]||""), nomor_surat:String(r[2]||""),
      tanggal_surat:formatDateInput(r[3]),tanggal_surat_display:formatDateDisplay(r[3]),
      tanggal_masuk:formatDateInput(r[4]),tanggal_masuk_display:formatDateDisplay(r[4]),
      asal_surat:String(r[5]||""),pengirim:String(r[6]||""),perihal:String(r[7]||""),
      jenis_surat:String(r[8]||"Surat Masuk"),sifat_surat:String(r[9]||"Biasa"),
      klasifikasi:String(r[10]||""),prioritas:String(r[11]||"Sedang"),
      tujuan_disposisi:String(r[12]||""),instruksi_disposisi:String(r[13]||""),
      tanggal_disposisi:formatDateInput(r[14]),tanggal_disposisi_display:formatDateDisplay(r[14]),
      target_penyelesaian:formatDateInput(r[15]),target_penyelesaian_display:formatDateDisplay(r[15]),
      penanggung_jawab:String(r[16]||""),tindak_lanjut:String(r[17]||""),
      progress,status,keterangan:String(r[20]||""),lampiran:String(r[21]||""),
      created_by:String(r[22]||"-"),created_at:formatDateDisplay(r[23]),updated_at:formatDateDisplay(r[24])
    });
  }
  return out.reverse();
}

function getDetailSurat(id) {
  return getAllSurat().find(x=>String(x.id)===String(id)) || null;
}

function validateForm(form) {
  if (!form.tanggal_surat || !form.tanggal_masuk || !form.perihal) throw new Error("Tanggal surat, tanggal masuk, dan perihal wajib diisi.");
  const p=Math.max(0,Math.min(100,Number(form.progress)||0));
  form.progress=p;
  return form;
}

function saveSurat(form,fileData,currentUser) {
  if (!currentUser || !canWrite(currentUser.role)) return {success:false,message:"Anda tidak memiliki hak untuk menyimpan data."};
  form=validateForm(form);
  const sh=getSheet("surat_masuk"), now=nowWita();
  let fileUrl="";
  if(fileData && fileData.base64){
    if(Number(fileData.size||0)>MAX_FILE_SIZE) return {success:false,message:"Ukuran lampiran melebihi 5 MB."};
    try{
      const raw=String(fileData.base64).split(",").pop();
      const blob=Utilities.newBlob(Utilities.base64Decode(raw),fileData.mimeType||"application/octet-stream",fileData.fileName||"lampiran");
      const file=getAttachmentFolder().createFile(blob);
      fileUrl=file.getUrl();
    }catch(e){ return {success:false,message:"Upload lampiran gagal: "+e.message}; }
  }
  const status=normalizeStatus(form.progress,form.target_penyelesaian);
  const values=[
    form.nomor_agenda||"",form.nomor_surat||"",form.tanggal_surat||"",form.tanggal_masuk||"",
    form.asal_surat||"",form.pengirim||"",form.perihal||"",form.jenis_surat||"Surat Masuk",
    form.sifat_surat||"Biasa",form.klasifikasi||"",form.prioritas||"Sedang",
    form.tujuan_disposisi||"",form.instruksi_disposisi||"",form.tanggal_disposisi||"",
    form.target_penyelesaian||"",form.penanggung_jawab||"",form.tindak_lanjut||"",
    form.progress,status,form.keterangan||"",fileUrl, currentUser.name, now, now
  ];
  if(form.id){
    const data=sh.getDataRange().getValues();
    for(let i=1;i<data.length;i++){
      if(String(data[i][0])===String(form.id)){
        const oldProgress=Number(data[i][18])||0, oldStatus=normalizeStatus(oldProgress,data[i][15]);
        if(!fileUrl) values[21]=data[i][21]||"";
        sh.getRange(i+1,2,1,24).setValues([values]);
        if(oldProgress!==form.progress || oldStatus!==status || form.keterangan || form.instruksi_disposisi){
          addHistory(form.id,oldProgress,form.progress,status,"Pembaruan tindak lanjut/disposisi: "+(form.keterangan||form.instruksi_disposisi||"-"),currentUser.name);
        }
        logAudit(currentUser.name,"UPDATE_SURAT","Update "+form.id+"; status="+status+"; progress="+form.progress+"%");
        return {success:true,message:"Data surat berhasil diperbarui."};
      }
    }
    return {success:false,message:"Data surat tidak ditemukan."};
  }
  const rowNo=sh.getLastRow()+1;
  const newId="SM-"+Utilities.formatDate(now,TZ,"yyMM")+"-"+String(rowNo-1).padStart(4,"0");
  sh.appendRow([newId].concat(values));
  addHistory(newId,0,form.progress,status,"Surat baru diregistrasikan.",currentUser.name);
  logAudit(currentUser.name,"INPUT_SURAT","Input surat baru "+newId);
  return {success:true,message:"Surat berhasil diregistrasikan dengan ID "+newId+"."};
}

function getHistori(suratId) {
  const sh=getSheet("histori_tindaklanjut"), data=sh.getDataRange().getValues(), list=[];
  for(let i=1;i<data.length;i++) if(String(data[i][1])===String(suratId)){
    list.push({tanggal:formatDateDisplay(data[i][2])+" "+Utilities.formatDate(parseDateSafely(data[i][2])||new Date(),TZ,"HH:mm"),aktivitas:data[i][3],progress_lama:data[i][4],progress_baru:data[i][5],status:data[i][6],keterangan:data[i][7],user:data[i][8]});
  }
  return list.reverse();
}

function addHistory(suratId,oldProg,newProg,status,ket,user) {
  getSheet("histori_tindaklanjut").appendRow(["HST-"+Date.now(),suratId,new Date(),"Tindak lanjut / disposisi",oldProg,newProg,status,ket,user]);
}

function logAudit(user,aksi,detail) {
  getSheet("audit_trail").appendRow(["LOG-"+Date.now(),new Date(),user,aksi,detail]);
}

function getReferenceData() {
  const sh=getSheet("users"), data=sh.getDataRange().getValues();
  const users=data.slice(1).filter(r=>r[5]==="Aktif").map(r=>({id:r[0],nama:r[1],role:r[4]}));
  return {
    users,
    jenis:["Surat Masuk","Undangan","Permohonan","Pemberitahuan","Laporan","Nota Dinas","Surat Tugas","Lainnya"],
    sifat:["Biasa","Segera","Penting","Rahasia","Sangat Rahasia"],
    prioritas:["Rendah","Sedang","Tinggi"],
    klasifikasi:["Administrasi","Kepegawaian","Keuangan","BMN","P4GN","Rehabilitasi","Penyuluhan","Kerja Sama","Hukum","Perencanaan","Pengawasan","Lainnya"],
    unit:["Kepala BNNK Bitung","Subbagian Umum","Seksi Pencegahan dan Pemberdayaan Masyarakat","Seksi Rehabilitasi","Seksi Pemberantasan","Tim/Pejabat yang ditunjuk"]
  };
}

function exportSuratCsv(currentUser) {
  if(!currentUser) throw new Error("Login diperlukan.");
  const list=getAllSurat();
  const headers=["ID","No Agenda","No Surat","Tgl Surat","Tgl Masuk","Asal Surat","Pengirim","Perihal","Jenis","Sifat","Klasifikasi","Prioritas","Tujuan Disposisi","Instruksi","Tgl Disposisi","Target","Penanggung Jawab","Tindak Lanjut","Progress","Status","Keterangan"];
  const rows=[headers].concat(list.map(d=>[d.id,d.nomor_agenda,d.nomor_surat,d.tanggal_surat_display,d.tanggal_masuk_display,d.asal_surat,d.pengirim,d.perihal,d.jenis_surat,d.sifat_surat,d.klasifikasi,d.prioritas,d.tujuan_disposisi,d.instruksi_disposisi,d.tanggal_disposisi_display,d.target_penyelesaian_display,d.penanggung_jawab,d.tindak_lanjut,d.progress+"%",d.status,d.keterangan]));
  return rows.map(r=>r.map(v=>'"'+String(v??"").replace(/"/g,'""')+'"').join(",")).join("\n");
}
