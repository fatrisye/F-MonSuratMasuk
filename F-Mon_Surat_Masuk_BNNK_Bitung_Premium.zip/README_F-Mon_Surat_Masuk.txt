e-MON SURAT BNNK BITUNG
=======================

Berkas:
1. Code_GS_BNNK_Bitung.gs -> tempel ke file Code.gs di Google Apps Script.
2. Index_BNNK_Bitung.html -> buat file HTML bernama Index.html dan tempel isinya.

Perubahan utama:
- Seluruh branding PLN ULP Bitung diubah menjadi BNNK Bitung.
- Terminologi surat disesuaikan dengan administrasi persuratan/disposisi BNNK.
- Register: nomor agenda, nomor surat, tanggal, asal/pengirim, jenis, sifat, klasifikasi, prioritas.
- Modul disposisi: tujuan disposisi, instruksi, tanggal disposisi, PIC, target.
- Monitoring progress, status otomatis, early warning H-3 dan overdue.
- Histori tindak lanjut dan audit trail.
- Role: ADMIN, PIMPINAN, PETUGAS.
- Dashboard internal wajib login.
- Password default menggunakan SHA-256; kompatibilitas password lama masih didukung.
- Lampiran maksimal 5 MB dan tidak dibuat publik otomatis.
- Export CSV.
- Zona waktu Asia/Makassar (WITA).

AKUN DEFAULT:
admin / admin123
pimpinan / bnnk123
petugas / petugas123

SETUP:
1. Buat/buka Google Spreadsheet yang akan menjadi database.
2. Extensions > Apps Script.
3. Buat Code.gs dan Index.html.
4. Tempel kedua source.
5. Jalankan initDatabase() sekali dari Apps Script atau menu e-MON SURAT BNNK.
6. Berikan izin Google Sheets/Drive saat diminta.
7. Deploy > New deployment > Web app.
8. Pilih Execute as: Me.
9. Atur siapa yang boleh mengakses sesuai kebijakan kantor/Google Workspace.
10. Setelah berhasil, ganti password default pada sheet users.

CATATAN:
- Untuk data surat yang bersifat Rahasia/Sangat Rahasia, sebaiknya Web App dan folder Drive dibatasi ke akun/Domain BNNK sesuai kebijakan keamanan informasi. Source ini tidak lagi mengaktifkan ANYONE_WITH_LINK pada lampiran.
- Struktur organisasi/unit pada dropdown dapat disesuaikan di fungsi getReferenceData().


VERSI PREMIUM — F-MON SURAT MASUK
- Nama aplikasi: F-Mon Surat Masuk.
- Tampilan premium/minimalis dengan navigasi dan elemen informasi yang tidak esensial dikurangi.
- Logo BNN menggunakan URL Wikimedia Commons yang diberikan pengguna.
- Export file menggunakan nama F-Mon_Surat_Masuk_BNNK_Bitung.
